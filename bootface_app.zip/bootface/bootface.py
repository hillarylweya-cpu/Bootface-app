"""
BootFace — Custom Android Boot Logo Changer
No root required. Uses ADB over USB.
Run: python bootface.py
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
import threading
import os
import sys
import zipfile
import shutil
import platform
from PIL import Image, ImageTk
import tempfile
import time


# ─── THEME ────────────────────────────────────────────────────────────────────
BG         = "#0D0D0F"
SURFACE    = "#17171A"
SURFACE2   = "#1F1F24"
BORDER     = "#2E2E35"
ACCENT     = "#4F8EF7"
ACCENT2    = "#7B5CF0"
SUCCESS    = "#22C55E"
WARNING    = "#F59E0B"
DANGER     = "#EF4444"
TEXT       = "#F0F0F5"
TEXT2      = "#8B8B99"
TEXT3      = "#52525E"
FONT_TITLE = ("Courier New", 22, "bold")
FONT_HEAD  = ("Courier New", 13, "bold")
FONT_BODY  = ("Courier New", 11)
FONT_SMALL = ("Courier New", 9)
FONT_MONO  = ("Courier New", 10)


# ─── ADB HELPER ───────────────────────────────────────────────────────────────
def adb(args, timeout=10):
    """Run an adb command. Returns (returncode, stdout, stderr)."""
    cmd = ["adb"] + args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except FileNotFoundError:
        return -1, "", "ADB not found. Please install Android Platform Tools."
    except subprocess.TimeoutExpired:
        return -1, "", "ADB command timed out."


def adb_devices():
    code, out, err = adb(["devices"])
    if code != 0:
        return []
    lines = out.strip().splitlines()[1:]
    devices = []
    for line in lines:
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            devices.append(parts[0])
    return devices


def adb_get_model(serial):
    _, out, _ = adb(["-s", serial, "shell", "getprop", "ro.product.model"])
    return out.strip() or "Unknown device"


def adb_get_android_version(serial):
    _, out, _ = adb(["-s", serial, "shell", "getprop", "ro.build.version.release"])
    return out.strip() or "?"


def adb_push_bootanim(serial, zip_path, log_fn):
    """Push bootanimation.zip to device via ADB (works on many OEMs without root)."""
    remote = "/sdcard/bootanimation.zip"

    log_fn("Pushing bootanimation.zip to device...")
    code, out, err = adb(["-s", serial, "push", zip_path, remote], timeout=30)
    if code != 0:
        return False, f"Push failed: {err}"
    log_fn("File pushed to /sdcard/bootanimation.zip")

    # Try OEM-specific paths that some manufacturers allow
    oem_paths = [
        "/data/local/bootanimation.zip",   # Many stock Android
        "/system/media/bootanimation.zip", # Requires root — will fail gracefully
        "/oem/media/bootanimation.zip",    # Some Samsung/LG
    ]

    log_fn("Attempting to copy to system paths...")
    success_path = None
    for path in oem_paths:
        code, out, err = adb(["-s", serial, "shell",
            f"cp {remote} {path} 2>/dev/null && echo OK || echo FAIL"])
        if "OK" in out:
            success_path = path
            log_fn(f"Installed to: {path}")
            break

    if success_path:
        log_fn("Setting permissions...")
        adb(["-s", serial, "shell", f"chmod 644 {success_path}"])
        return True, success_path
    else:
        # Fallback: keep it on /sdcard and provide instructions
        log_fn("System paths require root. File is at /sdcard/bootanimation.zip")
        log_fn("TIP: Some OEMs read from /sdcard — try rebooting now!")
        return True, "/sdcard/bootanimation.zip"


# ─── BOOTANIMATION BUILDER ────────────────────────────────────────────────────
def build_bootanimation_zip(image_path, output_zip, size=(1080, 1920),
                             fps=30, duration_sec=3, log_fn=print):
    """
    Convert any image/GIF into a valid Android bootanimation.zip
    Format: zip containing desc.txt + part0/ folder with PNG frames
    """
    log_fn("Loading image...")
    img = Image.open(image_path)
    w, h = size

    frames = []

    # Handle animated GIF
    if hasattr(img, 'n_frames') and img.n_frames > 1:
        log_fn(f"Animated image detected: {img.n_frames} frames")
        for i in range(img.n_frames):
            img.seek(i)
            frame = img.convert("RGBA")
            bg = Image.new("RGBA", frame.size, (0, 0, 0, 255))
            bg.paste(frame, mask=frame.split()[3])
            frame_rgb = bg.convert("RGB")
            frames.append(frame_rgb)
    else:
        # Static image — duplicate for duration
        n_frames = fps * duration_sec
        log_fn(f"Static image — generating {n_frames} frames at {fps}fps")
        frame = img.convert("RGB")
        frames = [frame] * n_frames

    # Resize all frames
    log_fn(f"Resizing frames to {w}x{h}...")
    resized = []
    for f in frames:
        # Fit inside screen with black bars
        f_copy = f.copy()
        f_copy.thumbnail((w, h), Image.LANCZOS)
        bg = Image.new("RGB", (w, h), (0, 0, 0))
        x = (w - f_copy.width) // 2
        y = (h - f_copy.height) // 2
        bg.paste(f_copy, (x, y))
        resized.append(bg)

    tmpdir = tempfile.mkdtemp(prefix="bootface_")
    part_dir = os.path.join(tmpdir, "part0")
    os.makedirs(part_dir)

    log_fn("Writing PNG frames...")
    for i, frame in enumerate(resized):
        frame.save(os.path.join(part_dir, f"{i:04d}.png"), "PNG", optimize=False)

    # Write desc.txt — Android bootanimation manifest
    desc = f"{w} {h} {fps}\np 1 0 part0\n"
    with open(os.path.join(tmpdir, "desc.txt"), "w") as f:
        f.write(desc)

    log_fn("Packing bootanimation.zip...")
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_STORED) as zf:
        zf.write(os.path.join(tmpdir, "desc.txt"), "desc.txt")
        for fname in sorted(os.listdir(part_dir)):
            zf.write(os.path.join(part_dir, fname), f"part0/{fname}")

    shutil.rmtree(tmpdir)
    log_fn(f"bootanimation.zip ready ({os.path.getsize(output_zip)//1024} KB)")
    return output_zip


# ─── MAIN GUI ─────────────────────────────────────────────────────────────────
class BootFaceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BootFace")
        self.root.geometry("780x680")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)

        self.image_path = None
        self.selected_device = tk.StringVar()
        self.resolution = tk.StringVar(value="1080x1920")
        self.fps = tk.IntVar(value=30)
        self.duration = tk.IntVar(value=3)
        self.preview_img = None

        self._build_ui()
        self._refresh_devices()

    def _build_ui(self):
        # ── Header ──
        hdr = tk.Frame(self.root, bg=BG)
        hdr.pack(fill="x", padx=28, pady=(24, 0))

        tk.Label(hdr, text="BOOTFACE", font=("Courier New", 28, "bold"),
                 bg=BG, fg=ACCENT).pack(side="left")
        tk.Label(hdr, text=" // boot logo changer", font=FONT_BODY,
                 bg=BG, fg=TEXT3).pack(side="left", pady=(8,0))

        # Status pill
        self.status_dot = tk.Label(hdr, text="● NO DEVICE", font=FONT_SMALL,
                                    bg=BG, fg=DANGER)
        self.status_dot.pack(side="right", pady=(8,0))

        # Divider
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x", padx=28, pady=14)

        # ── Main layout: left + right ──
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=28, pady=0)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left  = tk.Frame(body, bg=BG)
        right = tk.Frame(body, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0,10))
        right.grid(row=0, column=1, sticky="nsew", padx=(10,0))

        # ─ LEFT COLUMN ─

        # Device section
        self._section(left, "01 // CONNECT DEVICE")
        dev_row = tk.Frame(left, bg=BG)
        dev_row.pack(fill="x", pady=(4,0))

        self.device_menu = ttk.Combobox(dev_row, textvariable=self.selected_device,
                                         state="readonly", font=FONT_MONO, width=22)
        self.device_menu.pack(side="left", fill="x", expand=True)
        self._style_combo(self.device_menu)

        tk.Button(dev_row, text="↻", font=FONT_BODY, bg=SURFACE2, fg=ACCENT,
                  bd=0, padx=8, pady=4, cursor="hand2",
                  command=self._refresh_devices).pack(side="left", padx=(6,0))

        self.device_info = tk.Label(left, text="No device connected",
                                     font=FONT_SMALL, bg=BG, fg=TEXT3,
                                     anchor="w")
        self.device_info.pack(fill="x", pady=(4, 12))

        # Instructions
        self._section(left, "HOW TO ENABLE USB DEBUGGING")
        steps = [
            "1. Settings → About phone",
            "2. Tap 'Build number' 7 times",
            "3. Settings → Developer options",
            "4. Enable 'USB debugging'",
            "5. Connect USB cable → tap Allow",
        ]
        for s in steps:
            tk.Label(left, text=s, font=FONT_SMALL, bg=BG, fg=TEXT2,
                     anchor="w").pack(fill="x")

        tk.Frame(left, bg=BORDER, height=1).pack(fill="x", pady=12)

        # Resolution
        self._section(left, "02 // SCREEN RESOLUTION")
        res_opts = ["720x1280","1080x1920","1080x2340","1080x2400","1440x3200"]
        res_menu = ttk.Combobox(left, textvariable=self.resolution,
                                 values=res_opts, state="readonly",
                                 font=FONT_MONO, width=16)
        res_menu.pack(anchor="w", pady=(4,0))
        self._style_combo(res_menu)
        tk.Label(left, text="Match your phone's screen resolution",
                 font=FONT_SMALL, bg=BG, fg=TEXT3, anchor="w").pack(fill="x", pady=(2,10))

        # FPS + Duration
        self._section(left, "03 // ANIMATION SETTINGS")
        sl_frame = tk.Frame(left, bg=BG)
        sl_frame.pack(fill="x", pady=4)

        self._slider_row(sl_frame, "FPS", self.fps, 10, 60, 0)
        self._slider_row(sl_frame, "Duration (sec)", self.duration, 1, 10, 1)

        # ─ RIGHT COLUMN ─

        # Image picker
        self._section(right, "04 // PICK YOUR IMAGE / GIF")

        self.preview_box = tk.Label(right, bg=SURFACE,
                                     width=28, height=12,
                                     text="click to choose image",
                                     font=FONT_SMALL, fg=TEXT3,
                                     cursor="hand2",
                                     relief="flat",
                                     bd=0)
        self.preview_box.pack(fill="x", pady=(4,0))
        self.preview_box.bind("<Button-1>", lambda e: self._pick_image())

        tk.Frame(right, bg=BORDER, height=1).pack(fill="x", pady=(10,6))

        self.img_label = tk.Label(right, text="No image selected",
                                   font=FONT_SMALL, bg=BG, fg=TEXT3, anchor="w")
        self.img_label.pack(fill="x")

        # Flash button
        self.flash_btn = tk.Button(
            right, text="⚡  FLASH BOOT LOGO",
            font=FONT_HEAD, bg=ACCENT, fg="#ffffff",
            bd=0, padx=0, pady=14,
            cursor="hand2", activebackground=ACCENT2,
            command=self._start_flash)
        self.flash_btn.pack(fill="x", pady=(16, 0))

        # Save ZIP only button
        tk.Button(right, text="↓  Save bootanimation.zip only",
                  font=FONT_SMALL, bg=SURFACE2, fg=TEXT2,
                  bd=0, padx=0, pady=8, cursor="hand2",
                  command=self._save_zip_only).pack(fill="x", pady=(6,0))

        # ── Log ──
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x", padx=28, pady=(14,0))

        log_hdr = tk.Frame(self.root, bg=BG)
        log_hdr.pack(fill="x", padx=28, pady=(6,2))
        tk.Label(log_hdr, text="LOG", font=FONT_SMALL, bg=BG, fg=TEXT3).pack(side="left")
        tk.Button(log_hdr, text="clear", font=FONT_SMALL, bg=BG, fg=TEXT3,
                  bd=0, cursor="hand2",
                  command=lambda: self.log_box.delete("1.0","end")).pack(side="right")

        log_frame = tk.Frame(self.root, bg=SURFACE, bd=0)
        log_frame.pack(fill="x", padx=28, pady=(0,16))

        self.log_box = tk.Text(log_frame, height=6, bg=SURFACE, fg=SUCCESS,
                                font=FONT_MONO, bd=0, padx=10, pady=8,
                                state="disabled", wrap="word",
                                insertbackground=SUCCESS)
        self.log_box.pack(fill="both")
        self._log("BootFace ready. Connect your Android phone via USB.")

    def _section(self, parent, text):
        tk.Label(parent, text=text, font=FONT_SMALL, bg=BG, fg=TEXT3,
                 anchor="w").pack(fill="x", pady=(0,2))

    def _slider_row(self, parent, label, var, lo, hi, row):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="x", pady=2)
        tk.Label(f, text=label, font=FONT_SMALL, bg=BG, fg=TEXT2,
                 width=14, anchor="w").pack(side="left")
        tk.Scale(f, from_=lo, to=hi, orient="horizontal",
                 variable=var, bg=BG, fg=TEXT, highlightthickness=0,
                 troughcolor=SURFACE2, activebackground=ACCENT,
                 bd=0, sliderrelief="flat").pack(side="left", fill="x", expand=True)
        tk.Label(f, textvariable=var, font=FONT_MONO, bg=BG, fg=ACCENT,
                 width=3).pack(side="left")

    def _style_combo(self, combo):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TCombobox",
            fieldbackground=SURFACE2, background=SURFACE2,
            foreground=TEXT, bordercolor=BORDER,
            arrowcolor=ACCENT, selectbackground=SURFACE2,
            selectforeground=TEXT)

    def _log(self, msg):
        def _do():
            self.log_box.config(state="normal")
            self.log_box.insert("end", f"› {msg}\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.root.after(0, _do)

    def _refresh_devices(self):
        self._log("Scanning for ADB devices...")
        devices = adb_devices()
        if not devices:
            self.device_menu["values"] = ["No devices found"]
            self.selected_device.set("No devices found")
            self.device_info.config(text="Connect phone + enable USB debugging", fg=WARNING)
            self.status_dot.config(text="● NO DEVICE", fg=DANGER)
            self._log("No devices. Enable USB debugging and reconnect.")
            return

        self.device_menu["values"] = devices
        self.selected_device.set(devices[0])
        model   = adb_get_model(devices[0])
        version = adb_get_android_version(devices[0])
        self.device_info.config(
            text=f"{model}  ·  Android {version}  ·  {devices[0]}", fg=SUCCESS)
        self.status_dot.config(text=f"● {len(devices)} DEVICE(S)", fg=SUCCESS)
        self._log(f"Found: {model} (Android {version})")

    def _pick_image(self):
        path = filedialog.askopenfilename(
            title="Choose boot logo image",
            filetypes=[
                ("Images & GIFs", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"),
                ("All files", "*.*")
            ])
        if not path:
            return
        self.image_path = path
        fname = os.path.basename(path)
        self.img_label.config(text=fname, fg=TEXT)
        self._log(f"Image loaded: {fname}")

        # Show preview
        try:
            img = Image.open(path)
            img.thumbnail((240, 180), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            self.preview_img = photo
            self.preview_box.config(image=photo, text="")
        except Exception as e:
            self._log(f"Preview failed: {e}")

    def _get_output_zip(self):
        tmpdir = tempfile.mkdtemp(prefix="bootface_out_")
        return os.path.join(tmpdir, "bootanimation.zip")

    def _build_zip(self):
        res = self.resolution.get().split("x")
        w, h = int(res[0]), int(res[1])
        out  = self._get_output_zip()
        build_bootanimation_zip(
            self.image_path, out,
            size=(w, h),
            fps=self.fps.get(),
            duration_sec=self.duration.get(),
            log_fn=self._log)
        return out

    def _start_flash(self):
        if not self.image_path:
            messagebox.showwarning("No image", "Please select an image first.")
            return
        serial = self.selected_device.get()
        if not serial or serial == "No devices found":
            messagebox.showwarning("No device", "Please connect a device first.")
            return

        self.flash_btn.config(state="disabled", text="Working...")
        threading.Thread(target=self._flash_worker,
                         args=(serial,), daemon=True).start()

    def _flash_worker(self, serial):
        try:
            self._log("─" * 40)
            self._log("Building bootanimation.zip...")
            zip_path = self._build_zip()

            ok, result = adb_push_bootanim(serial, zip_path, self._log)
            if ok:
                self._log("─" * 40)
                self._log("SUCCESS! Boot logo installed.")
                self._log(f"Location: {result}")
                self._log("Reboot your phone to see the new boot logo!")
                self.root.after(0, lambda: messagebox.showinfo(
                    "Done!",
                    "Boot logo installed!\n\n"
                    f"Saved to: {result}\n\n"
                    "Reboot your phone to see your new boot animation."))
            else:
                self._log(f"FAILED: {result}")
                self.root.after(0, lambda: messagebox.showerror("Failed", result))
        except Exception as e:
            self._log(f"Error: {e}")
            self.root.after(0, lambda: messagebox.showerror("Error", str(e)))
        finally:
            self.root.after(0, lambda: self.flash_btn.config(
                state="normal", text="⚡  FLASH BOOT LOGO"))

    def _save_zip_only(self):
        if not self.image_path:
            messagebox.showwarning("No image", "Please select an image first.")
            return
        save_path = filedialog.asksaveasfilename(
            defaultextension=".zip",
            filetypes=[("ZIP files", "*.zip")],
            initialfile="bootanimation.zip")
        if not save_path:
            return

        def worker():
            try:
                zip_path = self._build_zip()
                shutil.copy(zip_path, save_path)
                self._log(f"Saved to: {save_path}")
                self.root.after(0, lambda: messagebox.showinfo(
                    "Saved", f"bootanimation.zip saved to:\n{save_path}\n\n"
                    "You can flash this manually via TWRP or ADB."))
            except Exception as e:
                self._log(f"Error: {e}")

        threading.Thread(target=worker, daemon=True).start()


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────
def main():
    root = tk.Tk()
    root.title("BootFace")
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    app = BootFaceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
