@echo off
title BootFace Launcher
echo.
echo  BootFace — Android Boot Logo Changer
echo  ======================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found.
    echo  Download from https://python.org and install it.
    echo  Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

:: Check/install Pillow
echo  Checking dependencies...
python -c "import PIL" >nul 2>&1
if errorlevel 1 (
    echo  Installing Pillow...
    pip install Pillow --quiet
)

:: Check ADB
adb version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [WARNING] ADB not found in PATH.
    echo  Download Android Platform Tools from:
    echo  https://developer.android.com/tools/releases/platform-tools
    echo  Extract it and add the folder to your PATH, or place adb.exe
    echo  in the same folder as bootface.py
    echo.
    echo  Press any key to launch anyway (ADB detection will show in app)
    pause >nul
)

echo  Launching BootFace...
python bootface.py
