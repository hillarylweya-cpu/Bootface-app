#!/bin/bash
echo ""
echo " BootFace — Android Boot Logo Changer"
echo " ======================================"
echo ""

# Check Python
if ! command -v python3 &>/dev/null; then
    echo " [ERROR] Python 3 not found."
    echo " Install it from https://python.org"
    exit 1
fi

# Check/install Pillow
python3 -c "import PIL" &>/dev/null || {
    echo " Installing Pillow..."
    pip3 install Pillow --quiet
}

# Check ADB
if ! command -v adb &>/dev/null; then
    echo " [WARNING] ADB not found."
    echo " Install Android Platform Tools:"
    echo "   Mac:   brew install android-platform-tools"
    echo "   Linux: sudo apt install adb"
    echo ""
fi

echo " Launching BootFace..."
python3 bootface.py
