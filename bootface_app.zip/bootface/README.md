# BootFace 🚀
### Custom Android Boot Logo Changer — No Root Required

Change your Android phone's boot animation to any image or GIF you want,
using only a USB cable and USB debugging. No root. No warranty void.

---

## Quick Start

### Step 1 — Install Python
Download from https://python.org (3.8 or newer)
- Windows: check ✅ "Add Python to PATH" during install

### Step 2 — Install ADB (Android Platform Tools)
Download from: https://developer.android.com/tools/releases/platform-tools

- **Windows**: Extract ZIP → add folder to PATH (or drop adb.exe next to bootface.py)
- **Mac**: `brew install android-platform-tools`
- **Linux**: `sudo apt install adb`

### Step 3 — Enable USB Debugging on your phone
1. Settings → About phone
2. Tap **Build number** 7 times fast → "You are now a developer!"
3. Settings → Developer options → Enable **USB debugging**
4. Connect phone via USB → tap **Allow** when prompted

### Step 4 — Run BootFace
- **Windows**: Double-click `run_windows.bat`
- **Mac/Linux**: Run `bash run_mac_linux.sh`
- **Any OS**: Run `python bootface.py`

---

## How It Works

1. You pick any **image or animated GIF**
2. BootFace converts it into `bootanimation.zip` — Android's boot animation format
3. It pushes the file to your phone via ADB
4. Reboot your phone → your custom logo appears!

---

## Compatibility

| Phone type          | Works? | Notes                              |
|---------------------|--------|------------------------------------|
| Stock Android 8–14  | ✅ Yes | Most devices                       |
| Samsung One UI      | ✅ Yes | Some models                        |
| Xiaomi / MIUI       | ✅ Yes | Enable "USB debugging"             |
| OnePlus / OxygenOS  | ✅ Yes | Works well                         |
| Pixel phones        | ✅ Yes | Full support                       |
| Rooted Android      | ✅ Yes | Best results                       |
| iOS / iPhone        | ❌ No  | Hardware locked — not possible     |

---

## Tips

- Use **1080x1920** or **1080x2340** for most modern phones
- PNG images give the cleanest results
- Animated GIFs make awesome boot animations
- If flash doesn't work automatically, use **"Save ZIP only"** and
  flash manually via TWRP recovery

---

## Files

```
bootface/
├── bootface.py          — Main application
├── requirements.txt     — Python dependencies
├── run_windows.bat      — Windows launcher
├── run_mac_linux.sh     — Mac/Linux launcher
└── README.md            — This file
```

---

Made with Python + ADB + love for phone customization.
